---
layout: "journal_by_tag"
tag: "tag01"
permalink: "/journal/tag/tag01/"
header-img: "img/archive-bg.jpg"
---